BLOW & GO / B02 WEBSITE

Location: Warszawa Śródmieście (no street address confirmed).

1. Open site/index.html locally to preview.
2. Edit CONFIG at top of generate.py, then run python generate.py.
3. Pages: 8 Polish and 8 English in site/en/.
4. Booking form is demonstrational; configure a backend before launch.
5. Map displays district, not exact salon location.
6. Strategy contradicts itself about walk-ins versus appointments; confirm before publication.
7. Do not publish invented prices, contacts, testimonials, opening hours.
8. Privacy policy, cookies, photo rights, real address, booking and domain must be confirmed.
9. robots.txt blocks indexing until launch; sitemap.xml needs a verified domain.
10. Only one illustrative hairstyle photo is used on homepage.
